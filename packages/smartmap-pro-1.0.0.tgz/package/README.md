# smartmap-pro

A commercial plug-and-play, isomorphic NPM package for interactive routing maps and secure backend fare calculations.

## Installation

```bash
npm install smartmap-pro react react-dom react-leaflet leaflet
```

## Features
- **Frontend Map Component (`SmartMap`)**: A React component that handles location selection and draws routes. For security, it does *not* calculate fares on the client side. Instead, it fires an `onOrderReady` event with exact coordinates.
- **Backend Helper (`calculateSecureFare`)**: A Node.js helper that securely requests the route distance from your routing server and calculates the final fare based on your private business rules.

## Usage

### 1. Frontend (React)

```tsx
import React from 'react';
import { SmartMap } from 'smartmap-pro';

function App() {
  const handleOrderReady = async (data: { startCoords: [number, number], endCoords: [number, number] }) => {
    // Send these coordinates to your own backend to securely calculate the price.
    const res = await fetch('/api/calculate-fare', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await res.json();
    console.log("Final Fare:", result.fare);
  };

  return (
    <SmartMap 
      osrmUrl="https://your-private-osrm-server.com/route/v1/driving" // Warning disabled
      onOrderReady={handleOrderReady}
      mode="full-feature"
    />
  );
}
export default App;
```

### 2. Backend (Node.js)

```typescript
import { calculateSecureFare } from 'smartmap-pro/server';

app.post('/api/calculate-fare', async (req, res) => {
  const { startCoords, endCoords } = req.body;
  const rates = {
    vehicles: {
      car: { baseFare: 150, costPerKm: 100, baseDistanceKm: 1 }
    }
  };

  try {
    const finalFare = await calculateSecureFare({
      startCoords,
      endCoords,
      vehicleType: 'car',
      rates,
      osrmUrl: "https://your-private-osrm-server.com/route/v1/driving" // Secure production routing
    });

    res.json({ fare: finalFare });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

### Customization & Feature Toggles

The `<SmartMap>` component accepts multiple props to heavily customize its look and behavior, turning it into a flexible commercial map.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `theme` | `"light" \| "dark"` | `"light"` | Use `"dark"` for a beautifully styled CartoDB dark mode tile. |
| `mode` | string | `"routing"` | `"routing"` (default), `"shop-location"` (single point, no routing), or `"location-only"`. |
| `shopCoords` | `[number, number]` | `undefined` | The coordinates `[lat, lng]` to display if `mode="shop-location"`. |
| `showZoomControls` | boolean | `true` | Show/hide the standard map `+` / `-` zoom buttons. |
| `interactiveMap` | boolean | `true` | If `false`, disables panning, scrolling, and touch, making the map static. |
| `showSearchBox` | boolean | `true` | Show/hide the embedded dummy search box UI overlay. |
| `customMarkerUrl`| string | `undefined` | Provide an image URL to replace the default Leaflet map pin. |
| `className` | string | `""` | A custom CSS class added to the outermost wrapper `div`. |

#### Advanced Example (Static Dark Mode Map)
Here is an example of a read-only, dark mode map centered on your shop with a custom marker icon:

```tsx
<SmartMap 
  mode="shop-location"
  theme="dark"
  shopCoords={[6.9271, 79.8612]} // Shop location
  showSearchBox={false}          // Hide search box
  showZoomControls={false}       // Hide zoom controls
  interactiveMap={false}         // Disable panning/scrolling
  customMarkerUrl="https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-gold.png"
/>
```

> [!CAUTION]
> ## 🚨 Production Routing Warning
> By default, if you do not provide an `osrmUrl` prop, this package falls back to the **public OSRM demo server** (`https://router.project-osrm.org`) for easy testing.
> 
> **DO NOT USE THIS PUBLIC DEMO SERVER IN A PRODUCTION APP.** It is not meant for commercial traffic and you will be rate-limited.
> You **MUST** provide your own custom `osrmUrl` in both the `<SmartMap />` component and the `calculateSecureFare` function before launching your app.
