import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Polyline, useMapEvents, useMap, LayersControl } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix default Leaflet icon paths in React
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png';
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';

const defaultIcon = L.icon({
  iconUrl,
  iconRetinaUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = defaultIcon;

export interface SmartMapProps {
  mode?: "routing" | "shop-location" | "location-only" | "full-feature";
  theme?: "light" | "dark" | "satellite" | "terrain";
  shopCoords?: [number, number];
  osrmUrl?: string;
  onOrderReady?: (data: { startCoords: [number, number]; endCoords: [number, number] }) => void;
  center?: [number, number];
  showZoomControls?: boolean;
  interactiveMap?: boolean;
  showSearchBox?: boolean;
  customMarkerUrl?: string;
  className?: string;
}

function MapClickHandler({ 
  startPoint, setStartPoint, 
  endPoint, setEndPoint,
  mode
}: {
  startPoint: [number, number] | null;
  setStartPoint: (val: [number, number] | null) => void;
  endPoint: [number, number] | null;
  setEndPoint: (val: [number, number] | null) => void;
  mode?: string;
}) {
  useMapEvents({
    click(e: any) {
      if (mode === "shop-location") return; // No clicks in shop mode

      if (!startPoint) { setStartPoint([e.latlng.lat, e.latlng.lng]); } 
      else if (!endPoint && mode !== "location-only") { setEndPoint([e.latlng.lat, e.latlng.lng]); } 
      else {
        setStartPoint([e.latlng.lat, e.latlng.lng]);
        if (mode !== "location-only") setEndPoint(null);
      }
    }
  });
  return null;
}

function MapUpdater({ routePath, center }: { routePath: [number, number][], center?: [number, number] }) {
  const map = useMap();

  const centerLat = center ? center[0] : null;
  const centerLng = center ? center[1] : null;

  // Smoothly fly to the location when center changes (e.g. search click)
  useEffect(() => {
    if (centerLat !== null && centerLng !== null) {
      map.flyTo([centerLat, centerLng], 14);
    }
  }, [centerLat, centerLng, map]);

  // Fit bounds to route
  useEffect(() => {
    if (routePath.length > 1) {
      map.fitBounds(L.latLngBounds(routePath), { padding: [50, 50] });
    }
  }, [routePath, map]);

  return null;
}

export default function SmartMap({
  mode = "routing",
  theme = "light",
  shopCoords,
  osrmUrl,
  onOrderReady,
  center = [6.9271, 79.8612],
  showZoomControls = true,
  interactiveMap = true,
  showSearchBox = true,
  customMarkerUrl,
  className = ""
}: SmartMapProps) {
  const [startPoint, setStartPoint] = useState<[number, number] | null>(null);
  const [endPoint, setEndPoint] = useState<[number, number] | null>(null);
  const [routePath, setRoutePath] = useState<[number, number][]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  // Search/Autocomplete State
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Handle Shop Location Mode
  const activeCenter = mode === "shop-location" && shopCoords ? shopCoords : center;
  const [mapCenter, setMapCenter] = useState<[number, number]>(activeCenter as [number, number]);

  const activeLat = activeCenter[0];
  const activeLng = activeCenter[1];

  // Sync prop center change securely using primitive values
  useEffect(() => {
    setMapCenter([activeLat, activeLng]);
  }, [activeLat, activeLng]);

  // Custom Icon
  const mapIcon = customMarkerUrl ? L.icon({
    iconUrl: customMarkerUrl,
    iconSize: [32, 32],
    iconAnchor: [16, 32]
  }) : defaultIcon;

  useEffect(() => {
    if (mode === "shop-location") return; // No routing in shop mode
    if (!startPoint || !endPoint || mode === "location-only") {
      setRoutePath([]); // Reset path if not routing
      return;
    }

    const fetchRoute = async () => {
      setErrorMessage(null);
      setIsCalculating(true);
      try {
        const activeOsrmUrl = osrmUrl || 'https://router.project-osrm.org/route/v1/driving';
        const fetchUrl = `${activeOsrmUrl}/${startPoint[1]},${startPoint[0]};${endPoint[1]},${endPoint[0]}?overview=full&geometries=geojson`;
        
        const osrmData = await (await fetch(fetchUrl)).json();
        if (osrmData.code !== 'Ok') return setErrorMessage("Failed to fetch route.");

        setRoutePath(osrmData.routes[0].geometry.coordinates.map((coord: [number, number]) => [coord[1], coord[0]]));

        if (onOrderReady) {
            onOrderReady({ startCoords: startPoint, endCoords: endPoint });
        }
      } catch (err) {
        setErrorMessage("Could not connect to the routing server.");
      } finally {
        setIsCalculating(false);
      }
    };
    fetchRoute();
  }, [startPoint, endPoint, mode, osrmUrl, onOrderReady]);

  // Autocomplete/Suggestions logic (with 500ms debounce)
  useEffect(() => {
    if (searchQuery.trim().length < 3) {
      setSearchResults([]);
      return;
    }

    const delayDebounceFn = setTimeout(async () => {
      setIsSearching(true);
      setErrorMessage(null);
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=5`);
        const data = await res.json();
        setSearchResults(data);
      } catch (err) {
        console.error("Autocomplete search error:", err);
      } finally {
        setIsSearching(false);
      }
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  const isUsingDemoServer = mode !== "shop-location" && mode !== "location-only" && !osrmUrl;

  const tileUrl = theme === "dark" 
    ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
    : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";

  const handleSelectLocation = (lat: string, lon: string) => {
    const latNum = parseFloat(lat);
    const lonNum = parseFloat(lon);
    
    // Pan the map
    setMapCenter([latNum, lonNum]);

    if (mode === "location-only") {
      setStartPoint([latNum, lonNum]);
    } else if (mode !== "shop-location") {
      if (!startPoint) {
        setStartPoint([latNum, lonNum]);
      } else if (!endPoint) {
        setEndPoint([latNum, lonNum]);
      } else {
        setStartPoint([latNum, lonNum]);
        setEndPoint(null);
      }
    }

    setSearchResults([]);
    setSearchQuery("");
  };

  return (
    <div className={`smart-map-container ${className}`} style={{ display: 'flex', flexDirection: 'column', gap: '20px', fontFamily: 'sans-serif', maxWidth: '800px', margin: '0 auto', position: 'relative' }}>
      
      {isUsingDemoServer && (
        <div style={{ padding: '12px 16px', background: '#fffbeb', color: '#b45309', borderRadius: '8px', border: '1px solid #fde68a' }}>
          ⚠️ Warning: Using public OSRM demo server. Not for commercial production.
        </div>
      )}

      {showSearchBox && (
        <div style={{ position: 'relative', zIndex: 10 }}>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center', padding: '10px 15px', background: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
            <input 
              type="text" 
              placeholder="Search location (Type at least 3 characters)..." 
              value={searchQuery} 
              onChange={(e) => setSearchQuery(e.target.value)} 
              style={{ width: '100%', border: 'none', outline: 'none', background: 'transparent' }} 
            />
            {isSearching && (
              <span style={{ fontSize: '0.8rem', color: '#9ca3af', animation: 'pulse 1s infinite' }}>Searching...</span>
            )}
          </div>

          {searchResults.length > 0 && (
            <ul style={{ position: 'absolute', width: '100%', top: '110%', left: 0, background: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', padding: 0, margin: 0, listStyle: 'none' }}>
              {searchResults.map((result) => (
                <li 
                  key={result.place_id} 
                  onClick={() => handleSelectLocation(result.lat, result.lon)}
                  style={{ padding: '10px 15px', borderBottom: '1px solid #f3f4f6', cursor: 'pointer', fontSize: '0.9rem' }}
                >
                  {result.display_name}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div style={{ height: '450px', width: '100%', borderRadius: '12px', overflow: 'hidden', zIndex: 1 }}>
        <MapContainer 
          center={mapCenter} 
          zoom={10} 
          style={{ height: '100%', width: '100%' }}
          zoomControl={showZoomControls}
          dragging={interactiveMap}
          scrollWheelZoom={interactiveMap}
          doubleClickZoom={interactiveMap}
          touchZoom={interactiveMap}
        >
          <LayersControl position="topright">
            <LayersControl.BaseLayer checked={theme === "light"} name="Standard Map">
              <TileLayer 
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
            </LayersControl.BaseLayer>
            
            <LayersControl.BaseLayer checked={theme === "dark"} name="Dark Mode">
              <TileLayer 
                url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
              />
            </LayersControl.BaseLayer>

            <LayersControl.BaseLayer checked={theme === "satellite"} name="Satellite Imagery">
              <TileLayer 
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
                attribution='Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
              />
            </LayersControl.BaseLayer>

            <LayersControl.BaseLayer checked={theme === "terrain"} name="Terrain Map">
              <TileLayer 
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}"
                attribution='Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ, TomTom, Intermap, iPC, USGS, FAO, NPS, NRCAN, GeoBase, Kadaster NL, Ordnance Survey, Esri Japan, METI, Esri China (Hong Kong), and the GIS User Community'
              />
            </LayersControl.BaseLayer>
          </LayersControl>
          
          {mode === "shop-location" && shopCoords && (
             <Marker position={shopCoords} icon={mapIcon} />
          )}

          {mode !== "shop-location" && (
            <>
              <MapClickHandler startPoint={startPoint} setStartPoint={setStartPoint} endPoint={endPoint} setEndPoint={setEndPoint} mode={mode} />
              {startPoint && <Marker position={startPoint} icon={mapIcon} />}
              {endPoint && <Marker position={endPoint} icon={mapIcon} />}
              {routePath.length > 0 && <Polyline positions={routePath} color="#4F46E5" weight={5} opacity={0.8} />}
            </>
          )}

          <MapUpdater routePath={routePath} center={mapCenter} />
        </MapContainer>
      </div>
      
      {errorMessage && <div style={{ color: '#991b1b' }}>{errorMessage}</div>}
      {isCalculating && <div style={{ color: '#4F46E5' }}>Calculating route...</div>}
    </div>
  );
}
