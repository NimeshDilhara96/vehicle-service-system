export { default as SmartMap } from './SmartMap';
