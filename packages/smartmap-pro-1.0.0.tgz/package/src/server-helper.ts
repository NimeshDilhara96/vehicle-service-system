export interface SecureFareParams {
    startCoords: [number, number];
    endCoords: [number, number];
    vehicleType: string;
    rates: any;
    osrmUrl?: string;
}

export async function calculateSecureFare({ 
    startCoords, 
    endCoords, 
    vehicleType, 
    rates, 
    osrmUrl 
}: SecureFareParams): Promise<{ totalCost: number, distanceKm: number }> {
    
    let activeOsrmUrl = osrmUrl;
    
    if (!activeOsrmUrl) {
        console.warn("⚠️ Warning: Using public OSRM demo server. Not for commercial production.");
        activeOsrmUrl = 'https://router.project-osrm.org/route/v1/driving';
    }

    // 1. Fetch exact distance securely from the routing server
    const fetchUrl = `${activeOsrmUrl}/${startCoords[1]},${startCoords[0]};${endCoords[1]},${endCoords[0]}?overview=false`;
    
    let distanceKm = 0;
    try {
        const response = await fetch(fetchUrl);
        const data = await response.json();
        
        if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
            throw new Error('Routing server failed to return a valid route.');
        }
        
        distanceKm = data.routes[0].distance / 1000;
    } catch (err: any) {
        throw new Error(`Failed to calculate secure distance: ${err.message}`);
    }

    // 2. Calculate fare based on business rules
    const vehicleConfig = rates.vehicles?.[vehicleType];

    if (!vehicleConfig) {
        throw new Error(`Invalid vehicle type: ${vehicleType}`);
    }

    const { baseFare, costPerKm, baseDistanceKm = 0 } = vehicleConfig;
    const rounding = rates.system?.distanceRounding || 'NONE';

    // Subtract the distance already covered by the base fare
    let billableDistance = distanceKm - baseDistanceKm;
    if (billableDistance < 0) {
        billableDistance = 0;
    }

    // Apply strict rounding rules configured by the business
    if (rounding === 'UP') {
        billableDistance = Math.ceil(billableDistance);
    } else if (rounding === 'DOWN') {
        billableDistance = Math.floor(billableDistance);
    }

    // Calculate final secure cost
    const totalCost = baseFare + (billableDistance * costPerKm);

    return { totalCost, distanceKm };
}
